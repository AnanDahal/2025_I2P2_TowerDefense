#include <string>

#include "ArmyEnemy.hpp"

ArmyEnemy::ArmyEnemy(int x, int y) : Enemy("play/enemy-2.png", x, y, 15, 30, 10, 10) {
}
