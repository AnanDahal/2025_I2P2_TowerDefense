#ifndef ARMYENEMY_HPP
#define ARMYENEMY_HPP
#include "Enemy.hpp"

class ArmyEnemy : public Enemy {
public:
    ArmyEnemy(int x, int y);
};
#endif   // ARMYENEMY_HPP
